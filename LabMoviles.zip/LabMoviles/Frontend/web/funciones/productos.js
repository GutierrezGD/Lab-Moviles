var info;
var value;

$(document).ready(function () {
    consultarProductos();
    consultarTipos();
    limpiarForm()
});

$(function () {
    $("#tablaProductos").html(""); 
    
    //muestra el enzabezado de la tabla
    var head = $("<thead/>");
    var row = $("<tr/>");
    head.append(row);
    $("#tablaProductos").append(head);
    row.append($("<th><b>Nombre</b></th>"));
    row.append($("<th><b>Importado</b></th>"));
    row.append($("<th><b>Precio</b></th>"));
    row.append($("<th><b>Tipo</b></th>"));
    row.append($("<th><b>Porcentaje</b></th>"));
    row.append($("<th><b>Impuesto</b></th>"));
    row.append($("<th><b>Precio Final</b></th>"));
    
    for (var i = 1; i < 11; i++) {
        var row = $("<tr />");
        row.addClass("page" + i);
        $("#tablaProductos").append(row);
    }
    
    //agrega los eventos las capas necesarias
    $("#agregar").click(function () {
        enviar();
    });

    //agrega los eventos las capas necesarias
    $("#buscarNombre").click(function () {
        buscarPorNombre();
    });
        
    $("#buscarTipo").click(function () {
        buscarPorTipo();
    });
});

function dibujarTabla(dataJson) {
    //limpia la información que tiene la tabla
    $("#tablaProductos").html(""); 
    
    //muestra el enzabezado de la tabla
    var head = $("<thead/>");
    var row = $("<tr/>");
    head.append(row);
    $("#tablaProductos").append(head); 
    row.append($("<th><b>Nombre</b></th>"));
    row.append($("<th><b>Importado</b></th>"));
    row.append($("<th><b>Precio</b></th>"));
    row.append($("<th><b>Tipo</b></th>"));
    row.append($("<th><b>Porcentaje</b></th>"));
    row.append($("<th><b>Impuesto</b></th>"));
    row.append($("<th><b>Precio Final</b></th>"));
    
    //carga la tabla con el json devuelto
    for (var i = 0; i < dataJson.length; i++) {
        dibujarFila(dataJson[i]);
    }
}

function dibujarFila(rowData) {
    var row = $("<tr/>");
    $("#tablaProductos").append(row);
    row.append($("<td>" + rowData.Nombre + "</td>"));
    if(rowData.Importado === 0){
        row.append($('<input type="checkbox" class="checkbox" disabled>'));
    }else{
        row.append($('<input type="checkbox" class="checkbox" checked disabled>'));
    }
    row.append($("<td>" + rowData.Precio + "</td>"));
    row.append($("<td>" + rowData.Tipo + "</td>"));
    row.append($("<td>" + rowData.Porcentaje + "</td>"));
    row.append($("<td>" + rowData.Impuesto + "</td>"));
    row.append($("<td>" + rowData.PrecioFinal + "</td>"));
}

function getImportado(){
    var valor;
    if (document.getElementById("importado").checked){
        valor = 1;
    }else{
        valor = 0;
    }
    return valor;
}

function enviar() {
    if (validar()) {
        //Se envia la información por ajax
        $.ajax({
            url: 'ProductoServlet',
            data: {
                accion: "agregarProducto",
                codigo: $("#codigo").val(),
                nombre: $("#nombre").val(),
                precio: $("#precio").val(),
                importado: getImportado(),
                tipo: $("#tipo").val()
            },
            error: function () { //si existe un error en la respuesta del ajax
                ocultarModal("myModal");
                swal('Error', 'Se genero un error, contacte al administrador (Error del ajax)', 'error');
            },
            success: function (data) { //si todo esta correcto en la respuesta del ajax, la respuesta queda en el data
                var respuestaTxt = data.substring(2);
                var tipoRespuesta = data.substring(0, 2);
                if (tipoRespuesta === "C~") { //correcto
                    swal('Correcto', respuestaTxt, 'success');
                    $("#myModalFormulario").modal("hide");
                    consultarProductos();
                } else {
                    if (tipoRespuesta === "E~") { //error
                        swal('Error', respuestaTxt, 'error');
                    } else {
                        swal('Error', 'Se genero un error, contacte al administrador', 'error');
                    }
                }
                ocultarModal("myModal");
            },
            type: 'POST'
        });
    } else {
        swal('Error', 'Debe digitar los campos del formulario', 'error');
    }
}

function validar() {
    var validacion = true;

    //Elimina estilo de error en los css
    //notese que es sobre el grupo que contienen el input
    $("#groupCodigo").removeClass("has-error");
    $("#groupNombre").removeClass("has-error");
    $("#groupPrecio").removeClass("has-error");
    $("#groupTipo").removeClass("has-error");

    //valida cada uno de los campos del formulario
    //Nota: Solo si fueron digitados
    if ($("#codigo").val() === "") {
        $("#groupCodigo").addClass("has-error");
        validacion = false;
    }
    if ($("#nombre").val() === "") {
        $("#groupNombre").addClass("has-error");
        validacion = false;
    }
    if ($("#precio").val() === "") {
        $("#groupPrecio").addClass("has-error");
        validacion = false;
    }
    if ($("#tipo").val() === "") {
        $("#groupTipo").addClass("has-error");
        validacion = false;
    }

    return validacion;
}

function mostrarMensaje(classCss, msg, neg) {
    //se le eliminan los estilos al mensaje
    $("#mesajeResult").removeClass();

    //se setean los estilos
    $("#mesajeResult").addClass(classCss);

    //se muestra la capa del mensaje con los parametros del metodo
    $("#mesajeResult").fadeIn("slow");
    $("#mesajeResultNeg").html(neg);
    $("#mesajeResultText").html(msg);
    $("#mesajeResultText").html(msg);
}

//******************************************************************************
//******************************************************************************

function limpiarForm() {
    $('#formProducto').trigger("reset");
}

//******************************************************************************
//Metodo de busqueda según el nombre
//******************************************************************************
function buscarPorNombre(){
    var name = document.getElementById("textoBuscarNombre").value;
    if(name !== ""){
        consultarProductoPorNombre(name);
    }else{
        consultarProductos();
    }
}

function buscarPorTipo(){
    var name = document.getElementById("textoBuscarTipo").value;
    consultarProductoPorTipo(name);
}

function consultarProductos() {
    mostrarModal("myModal", "Espere por favor..", "Consultando el producto seleccionado");
    //Se envia la información por ajax
    mostrarModal("myModal", "Espere por favor..", "Consultando la información de los Productos en la base de datos");
    //Se envia la información por ajax
    $.ajax({
        url: 'ProductoServlet',
        data: {
            accion: "consultarProductos"
        },
        error: function () { //si existe un error en la respuesta del ajax
            swal('Error', 'Se presento un error a la hora de cargar la información de los productos en la base de datos', 'error');
            ocultarModal("myModal");
        },
        success: function (data) { //si todo esta correcto en la respuesta del ajax, la respuesta queda en el data
            dibujarTabla(data);
            ocultarModal("myModal");
        },
        type: 'POST',
        dataType: "json"
    });
}

function consultarProductoPorTipo(tipo) {
    mostrarModal("myModal", "Espere por favor..", "Consultando el producto seleccionado");
    //Se envia la información por ajax
    mostrarModal("myModal", "Espere por favor..", "Consultando la información de los Productos en la base de datos");
    //Se envia la información por ajax
    $.ajax({
        url: 'ProductoServlet',
        data: {
            accion: "consultarProductoPorTipo",
            tipo: tipo
        },
        error: function () { //si existe un error en la respuesta del ajax
            swal('Error', 'Se presento un error a la hora de cargar la información de los productos en la base de datos', 'error');
            ocultarModal("myModal");
        },
        success: function (data) { //si todo esta correcto en la respuesta del ajax, la respuesta queda en el data
            dibujarTabla(data);
            ocultarModal("myModal");
        },
        type: 'POST',
        dataType: "json"
    });
}

function consultarProductoPorNombre(nombre) {
    mostrarModal("myModal", "Espere por favor..", "Consultando el producto seleccionado");
    //Se envia la información por ajax
    mostrarModal("myModal", "Espere por favor..", "Consultando la información de los Productos en la base de datos");
    //Se envia la información por ajax
    $.ajax({
        url: 'ProductoServlet',
        data: {
            accion: "consultarProductoPorNombre",
            nombre: nombre
        },
        error: function () { //si existe un error en la respuesta del ajax
            swal('Error', "No se encuentran datos", 'error');
            ocultarModal("myModal");
        },
        success: function (data) { //si todo esta correcto en la respuesta del ajax, la respuesta queda en el data
            dibujarTabla(data);
            ocultarModal("myModal");
        },
        type: 'POST',
        dataType: "json"
    });
}

function consultarTipos() {
    mostrarModal("myModal", "Espere por favor..", "Consultando la información de los choferes en la base de datos");
    //Se envia la información por ajax
    $.ajax({
        url: 'ProductoServlet',
        data: {
            accion: "consultarTipos"
        },
        error: function () { //si existe un error en la respuesta del ajax
            swal('Error', 'Se presento un error a la hora de cargar la información de los choferes en la base de datos', 'error');
            ocultarModal("myModal");
        },
        success: function (data) { //si todo esta correcto en la respuesta del ajax, la respuesta queda en el data
            info = data;
            var buscarTipo = document.getElementById("textoBuscarTipo");
            var tipo = document.getElementById("tipo");
            for (value in info) {
                var option1 = document.createElement("option");
                var option2 = document.createElement("option");
                option1.text = info[value].Nombre;
                option2.text = info[value].Nombre;
                tipo.add(option1);
                buscarTipo.add(option2);                
            }
            ocultarModal("myModal");
        },
        type: 'POST',
        dataType: "json"
    });
}

 function mostrarModal(idDiv ,titulo, mensaje){
     $("#"+idDiv+"Title").html(titulo);
     $("#"+idDiv+"Message").html(mensaje);
     $("#"+idDiv).modal();
 }
 
 function ocultarModal(idDiv){
     $("#"+idDiv).modal("hide");	
 }
 
  function cambiarMensajeModal(idDiv ,titulo, mensaje){
     $("#"+idDiv+"Title").html(titulo);
     $("#"+idDiv+"Message").html(mensaje);
 }