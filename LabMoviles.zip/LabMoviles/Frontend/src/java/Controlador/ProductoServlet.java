/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import com.google.gson.Gson;
import LogicaNegocio.Producto;
import LogicaNegocio.Tipo;
import LogicaNegocio.FlujoPrincipal;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Float.parseFloat;
import static java.lang.Integer.parseInt;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ProductoServlet extends HttpServlet{
  /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            //String para guardar el JSON generaro por al libreria GSON
            String json;
            
            //Se crea el objeto Chofer
            Producto p = new Producto();

            //Se crea el objeto de la logica de negocio
            FlujoPrincipal flujo = new FlujoPrincipal();
            
            
            //**********************************************************************
            //se toman los datos de la session
            //**********************************************************************
            HttpSession session = request.getSession();
            
            //**********************************************************************
            //se consulta cual accion se desea realizar
            //**********************************************************************
            String accion = request.getParameter("accion");
            switch (accion) {
                case "consultarProductos":
                    json = new Gson().toJson(flujo.listarProductos());
                    out.print(completarProductos(json, flujo));
                    break;  
                    
                case "consultarProductoPorNombre":
                    //se consulta las personas por Name
                    //revisar
                    json = new Gson().toJson(flujo.buscarProductoPorNombre(request.getParameter("nombre")));
                    out.print(completarProductos(json, flujo));
                    break;
                    
                case "consultarProductoPorTipo":
                    //se consulta las personas por Name
                    //revisar
                    json = new Gson().toJson(flujo.buscarProductoPorTipo(request.getParameter("tipo")));
                    out.print(completarProductos(json, flujo));
                    break;
                    
                case "agregarProducto":
                    //Se llena el objeto con los datos enviados por AJAX por el metodo post
                    p.setCodigo(request.getParameter("codigo"));
                    p.setNombre(request.getParameter("nombre"));
                    p.setPrecio(parseFloat(request.getParameter("precio")));
                    p.setImportado(parseInt(request.getParameter("importado")));
                    p.setTipo(request.getParameter("tipo"));
                        //Se guarda el objeto
                        flujo.insertarProducto(p);

                        //Se imprime la respuesta con el response
                        out.print("C~El Producto fue ingresado correctamente");               
                    break;
                    
                case "consultarTipos":    
                    json = new Gson().toJson(flujo.listarTipos());
                    out.print(json);
                    break;
                    
                default:
                    out.print("E~No se indico la acción que se desea realizare");
                    break;
            }

        } catch (NumberFormatException e) {
            out.print("E~" + e.getMessage());
        } catch (Exception e) {
            out.print("E~" + e.getMessage());
        }
    }
    
    protected JSONArray completarProductos(String json, FlujoPrincipal flujo) throws JSONException, Exception{
        String tipo;
        int importado;
        float precio, impuesto;

        JSONArray newArray = new JSONArray();
        JSONArray getArray = new JSONArray(json);

        for(int i = 0; i < getArray.length(); i++)
        {
            JSONObject objectInArray = getArray.getJSONObject(i);
            tipo = objectInArray.getString("Tipo");
            importado = objectInArray.getInt("Importado");
            precio = (float) objectInArray.getDouble("Precio");
            
            objectInArray.put("Porcentaje", flujo.buscarTipoPorNombre(objectInArray.getString("Tipo")).getPorcentaje());
            impuesto =  flujo.calcularImpuesto(tipo, importado, precio);
            objectInArray.put("Impuesto", (double) impuesto);
            objectInArray.put("PrecioFinal", (double)flujo.calcularPrecioFinal(impuesto, precio));
            newArray.put(objectInArray);
        }
        return newArray;
   }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold> 
}
