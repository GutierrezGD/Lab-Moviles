/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import java.util.List;
import Model.Model;
import Interfaz.Vista;
import Modelo.Producto;
import Modelo.Tipo;
import java.util.ArrayList;

/**
 *
 * @author Estefani
 */
public class ControlProducto {

    Model model;
    Vista view;
    Control domainModel;

    public ControlProducto(Vista view, Model model, Control domainModel) {
        model.init();
        this.domainModel = domainModel;

        this.view = view;
        this.model = model;
        view.setControlProducto(this);
        view.setModel(model);
    }

    public void buscarPorNombre() throws Exception{
        model.clearErrors();
        ArrayList rowsMod = (ArrayList) domainModel.buscarProductoPorNombre(view.BuscarNombre.getText());
        model.setProducto(rowsMod);
    }
    
    public void buscarPorTipo() throws Exception{
        model.clearErrors();
        ArrayList rowsMod = (ArrayList) domainModel.buscarProductoPorTipo(view.buscarTipo.getSelectedItem().toString());
        model.setProducto(rowsMod);
    }

    public void select(int row) throws Exception {
        model.clearErrors();
        model.setRow(row);
    }

    public void agregar()throws Exception {
        Producto p = new Producto();
        p.setCodigo(view.codigo.getText());
        p.setNombre(view.nombre.getText());
        p.setPrecio(Float.parseFloat(view.precio.getText()));
        p.setTipo(view.Tipo.getSelectedItem().toString());
        
        if (view.importado.isSelected()) 
            p.setImportado(1); 
        else 
            p.setImportado(0);
        
        domainModel.insertarProducto(p);
        
    }
    
    public ArrayList getProductos() throws Exception{
        return (ArrayList) domainModel.listarProductos();
    }
    
     public ArrayList getTipos() throws Exception{
        return (ArrayList) domainModel.listarTipos();
    }
    
}

