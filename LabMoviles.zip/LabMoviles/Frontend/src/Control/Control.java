/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import java.util.Collection;
import java.util.List;
import LogicaNegocio.FlujoPrincipal;
import Modelo.Producto;
import Modelo.Tipo;
/**
 *
 * @author Estefani
 */
public class Control {

    private FlujoPrincipal fp;

    private static Control uniqueInstance;

    public static Control instance() {
        if (uniqueInstance == null) {
            uniqueInstance = new Control();
        }
        return uniqueInstance;
    }

    private Control() {
        fp = new FlujoPrincipal();
    }
    
    //////////////////// Metodos Productos ////////////////////

    public void insertarProducto(Producto elProducto) throws Exception{
        fp.insertarProducto(elProducto);
    }
    
    public Collection listarProductos() throws Exception{
        return fp.listarProductos();
    }
    
    public Producto buscarProductoPorCodigo(String codigo) throws Exception{
        return fp.buscarProductoPorCodigo(codigo);
    }
    
    public Collection buscarProductoPorNombre(String nombre) throws Exception{
        return fp.buscarProductoPorNombre(nombre);
    }
    
    public Collection buscarProductoPorTipo(String tipo) throws Exception{
        return fp.buscarProductoPorTipo(tipo);
    }
    
    //////////////////// Metodos Tipo ////////////////////
    
    public Collection listarTipos() throws Exception{
        return fp.listarTipos();
    }
    
    public Tipo buscarTipoPorNombre(String nombre) throws Exception{
        return fp.buscarTipoPorNombre(nombre);
    }    
}

