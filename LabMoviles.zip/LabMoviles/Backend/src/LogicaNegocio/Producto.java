package LogicaNegocio;

/**
 *
 * @author Daniel Gutierrez
 */
public class Producto {
    private String Codigo;
    private String Nombre;
    private float Precio;
    private int Importado;
    private String Tipo;

    public Producto() {
        this.Codigo = "";
        this.Nombre = "";
        this.Precio = 0;
        this.Importado = 0;
        this.Tipo = "";
    }
    
    public Producto(String Codigo, String Nombre, float Precio, int Importado, String Tipo) {
        this.Codigo = Codigo;
        this.Nombre = Nombre;
        this.Precio = Precio;
        this.Importado = Importado;
        this.Tipo = Tipo;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public float getPrecio() {
        return Precio;
    }

    public void setPrecio(float Precio) {
        this.Precio = Precio;
    }

    public int getImportado() {
        return Importado;
    }

    public void setImportado(int Importado) {
        this.Importado = Importado;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }
}