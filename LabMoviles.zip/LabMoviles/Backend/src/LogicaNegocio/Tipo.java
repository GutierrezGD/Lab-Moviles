/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaNegocio;

/**
 *
 * @author Daniel Gutierrez
 */
public class Tipo {
    private String Nombre;
    private int porcentaje;

    public Tipo() {
        this.Nombre = "";
        this.porcentaje = 0;
    }
    
    public Tipo(String Nombre, int porcentaje) {
        this.Nombre = Nombre;
        this.porcentaje = porcentaje;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setPorcentaje(int porcentaje) {
        this.porcentaje = porcentaje;
    }

    public String getNombre() {
        return Nombre;
    }

    public int getPorcentaje() {
        return porcentaje;
    }
    
}
