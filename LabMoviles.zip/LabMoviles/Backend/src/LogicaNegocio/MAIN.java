package LogicaNegocio;

import Modelo.Producto;
import Modelo.Tipo;
import java.util.ArrayList;

/**
 *
 * @author Daniel Gutierrez
 */
public class MAIN {
    public static void main(String[] args) throws Exception {
        FlujoPrincipal flujo = new FlujoPrincipal();
        ArrayList listaP, listaT;
        float impuesto, precioFinal;
        //flujo.insertarProducto(new Producto("123","CocaCola",750,0,"Refrescos"));
        listaP = (ArrayList) flujo.listarProductos();
        flujo.buscarProductoPorNombre("CocaCola");
        flujo.buscarProductoPorTipo("Refrescos");
        flujo.buscarProductoPorCodigo("123");
        impuesto = flujo.calcularImpuesto("123");
        precioFinal = flujo.calcularPrecioFinal("123");
        listaT = (ArrayList) flujo.listarTipos();
        flujo.buscarTipoPorNombre("Refrescos");
        
    }
}
