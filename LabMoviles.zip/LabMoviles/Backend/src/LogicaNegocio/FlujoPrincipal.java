package LogicaNegocio;

import AccesoDatos.ServicioProducto;
import AccesoDatos.ServicioTipo;
import Modelo.Producto;
import Modelo.Tipo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

public class FlujoPrincipal {
    private final ServicioProducto servicioProducto;
    private final ServicioTipo servicioTipo;
    private static FlujoPrincipal uniqueInstance;

    public static FlujoPrincipal instance() {
        if (uniqueInstance == null) {
            uniqueInstance = new FlujoPrincipal();
        }
        return uniqueInstance;
    }

    public FlujoPrincipal() {
        servicioProducto = new ServicioProducto();
        servicioTipo = new ServicioTipo();
    }
    
    //////////////////// Metodos Producto ////////////////////
    
    public void insertarProducto(Producto elProducto) throws Exception{
        servicioProducto.insertarProducto(elProducto);
    }
    
    public Collection listarProductos() throws Exception{
        return servicioProducto.listarProductos();
    }
    
    public Producto buscarProductoPorCodigo(String codigo) throws Exception{
        return servicioProducto.buscarPorCodigo(codigo);
    }
    
    public Collection buscarProductoPorNombre(String nombre) throws Exception{
        return servicioProducto.buscarPorNombre(nombre);
    }
    
    public Collection buscarProductoPorTipo(String tipo) throws Exception{
        return servicioProducto.buscarPorTipo(tipo);
    }
    
    //////////////////// Metodos Tipo ////////////////////
    
    public Collection listarTipos() throws Exception{
        return servicioTipo.listarTipos();
    }
    
    public Tipo buscarTipoPorNombre(String nombre) throws Exception{
        return servicioTipo.buscarPorNombre(nombre);
    }
    
    //////////////////// Metodos Adicionales ////////////////////
    
    public float calcularImpuesto(String codigo) throws Exception{
        Producto producto = buscarProductoPorCodigo(codigo);
        Tipo tipo = buscarTipoPorNombre(producto.getTipo());
        float impuesto = producto.getPrecio() / tipo.getPorcentaje();
        return impuesto;
    }
    
    public float calcularPrecioFinal(String codigo) throws Exception{
        Producto producto = buscarProductoPorCodigo(codigo);
        float impuesto = calcularImpuesto(codigo);
        float precioFinal = producto.getPrecio() + impuesto;
        return precioFinal;
    }
}