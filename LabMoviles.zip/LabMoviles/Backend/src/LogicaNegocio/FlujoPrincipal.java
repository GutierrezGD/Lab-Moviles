package LogicaNegocio;

import AccesoDatos.ServicioProducto;
import AccesoDatos.ServicioTipo;
import java.util.Collection;

public class FlujoPrincipal {
    private final ServicioProducto servicioProducto;
    private final ServicioTipo servicioTipo;
    private static FlujoPrincipal uniqueInstance;

    public static FlujoPrincipal instance() {
        if (uniqueInstance == null) {
            uniqueInstance = new FlujoPrincipal();
        }
        return uniqueInstance;
    }

    public FlujoPrincipal() {
        servicioProducto = new ServicioProducto();
        servicioTipo = new ServicioTipo();
    }
    
    //////////////////// Metodos Producto ////////////////////
    
    public void insertarProducto(Producto elProducto) throws Exception{
        servicioProducto.insertarProducto(elProducto);
    }
    
    public Collection listarProductos() throws Exception{
        return servicioProducto.listarProductos();
    }
    
    public Producto buscarProductoPorCodigo(String codigo) throws Exception{
        return servicioProducto.buscarPorCodigo(codigo);
    }
    
    public Collection buscarProductoPorNombre(String nombre) throws Exception{
        return servicioProducto.buscarPorNombre(nombre);
    }
    
    public Collection buscarProductoPorTipo(String tipo) throws Exception{
        return servicioProducto.buscarPorTipo(tipo);
    }
    
    //////////////////// Metodos Tipo ////////////////////
    
    public Collection listarTipos() throws Exception{
        return servicioTipo.listarTipos();
    }
    
    public Tipo buscarTipoPorNombre(String nombre) throws Exception{
        return servicioTipo.buscarPorNombre(nombre);
    }
    
    //////////////////// Metodos Adicionales ////////////////////
        
    public float calcularImpuesto(String nombreTipo, int importado, float precio) throws Exception{
        Tipo tipo = buscarTipoPorNombre(nombreTipo);
        int porcentaje = tipo.getPorcentaje();
        float impuesto;
        if (importado == 0){
            return impuesto = (precio / 100)  * porcentaje;
        }else{
            return impuesto = (float) ((float) ((precio / 100)  * porcentaje) * 1.5);
        }
    }
    
    public float calcularPrecioFinal(float impuesto, float precio) throws Exception{
        float precioFinal = precio + impuesto;
        return precioFinal;
    }
}