package AccesoDatos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.CallableStatement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import LogicaNegocio.Producto;
import oracle.jdbc.OracleTypes;
/**
 *
 * @author Estudiante
 */
public class ServicioProducto extends Servicio
{

	private static final String insertarProducto = "{call insertarProducto (?,?,?,?,?)}";
	private static final String LISTAR = "{?=call listarProducto()}";
	private static final String BUSCARNOMBRE = "{?=call buscarProductoPorNombre(?)}";
        private static final String BUSCARTIPO = "{?=call buscarProductoPorTipo(?)}";

	/** Creates a new instance of ServicioLibro */
	public ServicioProducto()
	{
	}

	public Collection listarProducto() throws GlobalException, NoDataException
	{
		try
		{
			conectar();
		}
		catch (ClassNotFoundException ex)
		{
			throw new GlobalException("No se ha localizado el Driver");
		}

		catch (SQLException e)
		{
			throw new NoDataException("La base de datos no se encuentra disponible");
		}

		ResultSet rs = null;
		ArrayList coleccion = new ArrayList();
		Producto elProducto = null;
		CallableStatement pstmt = null;
		try
		{
			pstmt = conexion.prepareCall(LISTAR);
			pstmt.registerOutParameter(1, OracleTypes.CURSOR);
			pstmt.execute();
			rs = (ResultSet)pstmt.getObject(1);
			while (rs.next())
			{
				elProducto = new Producto(rs.getString("codigo"),
									   rs.getString("nombre"),
									   rs.getFloat("precio"),
									   rs.getInt("importado"),
									   rs.getString("tipo"));
				coleccion.add(elProducto);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();

			throw new GlobalException("Sentencia no valida");
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
				}
				if (pstmt != null)
				{
					pstmt.close();
				}
				desconectar();
			}
			catch (SQLException e)
			{
				throw new GlobalException("Estatutos invalidos o nulos");
			}
		}
		if (coleccion == null || coleccion.size() == 0)
		{
			throw new NoDataException("No hay datos");
		}
		return coleccion;
	}
	public void insertarProducto(Producto elProducto) throws GlobalException, NoDataException
	{
		try
		{
			conectar();
		}
		catch (ClassNotFoundException e)
		{
			throw new GlobalException("No se ha localizado el driver");
		}
		catch (SQLException e)
		{
			throw new NoDataException("La base de datos no se encuentra disponible");
		}
		CallableStatement pstmt = null;

		try
		{
			 
			pstmt = conexion.prepareCall(insertarProducto);
			pstmt.setString(1, elProducto.getCodigo());
			pstmt.setString(2, elProducto.getNombre());
			pstmt.setFloat(3, elProducto.getPrecio());
			pstmt.setInt(4, elProducto.getImportado());
			pstmt.setString(5, elProducto.getTipo());
			boolean resultado = pstmt.execute();
			if (resultado == true)
			{
				throw new NoDataException("No se realizo la inserción");
			}

		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new GlobalException("Llave duplicada");
		}
		finally
		{
			try
			{
				if (pstmt != null)
				{
					pstmt.close();
				}
				desconectar();
			}
			catch (SQLException e)
			{
				throw new GlobalException("Estatutos invalidos o nulos");
			}
		}
	}
	public Producto buscarPorNombre(String nombre) throws GlobalException, NoDataException
	{

		try
		{
			conectar();
		}
		catch (ClassNotFoundException e)
		{
			throw new GlobalException("No se ha localizado el driver");
		}
		catch (SQLException e)
		{
			throw new NoDataException("La base de datos no se encuentra disponible");
		}
		ResultSet rs = null;
		ArrayList coleccion = new ArrayList();
		Producto elProducto = null;
		CallableStatement pstmt = null;
		try
		{
			pstmt = conexion.prepareCall(BUSCARNOMBRE);
			pstmt.registerOutParameter(1, OracleTypes.CURSOR);
			pstmt.setString(2, nombre);
			pstmt.execute();
			rs = (ResultSet)pstmt.getObject(1);
			while (rs.next())
			{
				elProducto = new Producto(rs.getString("codigo"),
									   rs.getString("nombre"),
									   rs.getFloat("precio"),
									   rs.getInt("importado"),
									   rs.getString("tipo"));
				coleccion.add(elProducto);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();

			throw new GlobalException("Sentencia no valida");
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
				}
				if (pstmt != null)
				{
					pstmt.close();
				}
				desconectar();
			}
			catch (SQLException e)
			{
				throw new GlobalException("Estatutos invalidos o nulos");
			}
		}
		if (coleccion == null || coleccion.size() == 0)
		{
			throw new NoDataException("No hay datos");
		}
		return elProducto;
	}
        public Producto buscarPorTipo(String tipo) throws GlobalException, NoDataException
	{

		try
		{
			conectar();
		}
		catch (ClassNotFoundException e)
		{
			throw new GlobalException("No se ha localizado el driver");
		}
		catch (SQLException e)
		{
			throw new NoDataException("La base de datos no se encuentra disponible");
		}
		ResultSet rs = null;
		ArrayList coleccion = new ArrayList();
		Producto elProducto = null;
		CallableStatement pstmt = null;
		try
		{
			pstmt = conexion.prepareCall(BUSCARTIPO);
			pstmt.registerOutParameter(1, OracleTypes.CURSOR);
			pstmt.setString(2, tipo);
			pstmt.execute();
			rs = (ResultSet)pstmt.getObject(1);
			while (rs.next())
			{
				elProducto = new Producto(rs.getString("codigo"),
									   rs.getString("nombre"),
									   rs.getFloat("precio"),
									   rs.getInt("importado"),
									   rs.getString("tipo"));
				coleccion.add(elProducto);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();

			throw new GlobalException("Sentencia no valida");
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
				}
				if (pstmt != null)
				{
					pstmt.close();
				}
				desconectar();
			}
			catch (SQLException e)
			{
				throw new GlobalException("Estatutos invalidos o nulos");
			}
		}
		if (coleccion == null || coleccion.size() == 0)
		{
			throw new NoDataException("No hay datos");
		}
		return elProducto;
	}
}