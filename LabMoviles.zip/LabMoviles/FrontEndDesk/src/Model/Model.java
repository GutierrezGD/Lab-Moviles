/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Observer;
import LogicaNegocio.Producto;
/**
 *
 * @author Estefani
 */
public class Model extends java.util.Observable{
    Producto filter; 
    Producto current;
    int row;
    
    TableModel productos;
    HashMap<String,String> errores;
    String mensaje;  

    public Model() {
    }

    public void init(){ 
        filter = new Producto();
        clearErrors();
        ArrayList<Producto> rows = new ArrayList<>();
        this.setProducto(rows);

    }
    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public Producto getFilter() {
        return filter;
    }

    public void setFilter(Producto filter) {
        this.filter = filter;
    }
    
    public void setProducto(ArrayList<Producto> producto){
        int[] cols= {TableModel.NOMBRE, TableModel.IMPORTADO, TableModel.PRECIO, TableModel.TIPO,
                TableModel.PORCENTAJE, TableModel.IMPUESTO, TableModel.PRECIOFINAL};
                        
        this.productos =new TableModel(cols, producto);  
        setChanged();
        notifyObservers();        
    }
    
     public TableModel getProductos() {
        return productos;
    }

    @Override
    public void addObserver(Observer o) {
        super.addObserver(o);
        setChanged();
        notifyObservers();
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public HashMap<String, String> getErrores() {
        return errores;
    }

    public void setErrores(HashMap<String, String> errores) {
        this.errores = errores;
    }
    
    public void clearErrors(){
        setErrores(new HashMap<String,String>());
        setMensaje(""); 
    }
    
    public void commit(){
        setChanged();
        notifyObservers();       
    }
    
    public Producto getCurrent() {
        return current;
    }

    public void setCurrent(Producto current) {
        this.current = current;
        setChanged();
        notifyObservers();        
    }
}

