/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import AccesoDatos.GlobalException;
import AccesoDatos.NoDataException;
import javax.swing.table.AbstractTableModel;
import LogicaNegocio.Producto;
import java.util.ArrayList;
import AccesoDatos.ServicioTipo;
import Control.Control;
import LogicaNegocio.FlujoPrincipal;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Estefani
 */
public class TableModel  extends AbstractTableModel {

    ArrayList<Producto> rows = new ArrayList<>();
    int[] cols;
    String[] colNames = new String[11];
    Control control = new Control();
    
    public static final int NOMBRE = 0;
    public static final int IMPORTADO = 1;
    public static final int PRECIO = 2;
    public static final int TIPO = 3;
    public static final int PORCENTAJE = 4;
    public static final int IMPUESTO = 5;
    public static final int PRECIOFINAL = 6;
    
    /**
     *
     * @param cols
     * @param rows
     */
    public TableModel(int[] cols, ArrayList<Producto> rows) {
        this.rows = new ArrayList<>();
        this.cols = cols;
        this.rows = rows;
        initColNames();
    }
    
     public int getColumnCount() {
        return cols.length;
    }

    public String getColumnName(int col) {
        return colNames[cols[col]];
    }

    public int getRowCount() {
        return rows.size();
    }

    public Producto getRowAt(int row) {
        return rows.get(row);
    }

   public Object getValueAt(int row, int col) {
        Producto producto = rows.get(row);
        
        switch (cols[col]) {
            case NOMBRE:
                return producto.getNombre();
            case IMPORTADO:
                return producto.getImportado();
            case PRECIO:
                return producto.getPrecio();
            case TIPO: 
                return producto.getTipo();
            case PORCENTAJE:
        {
            try {
                return control.buscarTipoPorNombre(producto.getTipo()).getPorcentaje();
            } catch (Exception ex) {
                Logger.getLogger(TableModel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
            case IMPUESTO:
        {
            try {
                return control.calcularImpuesto((String) producto.getTipo(), producto.getImportado(), producto.getPrecio());
            } catch (Exception ex) {
                Logger.getLogger(TableModel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
            case PRECIOFINAL:
                float impuesto;
        try {
            impuesto = control.calcularImpuesto((String) producto.getTipo(), producto.getImportado(), producto.getPrecio());
            return control.calcularPrecioFinal(impuesto, producto.getPrecio());
        } catch (Exception ex) {
            Logger.getLogger(TableModel.class.getName()).log(Level.SEVERE, null, ex);
        }  
            default:
                return "";
        }
    }
   
   
       private void initColNames() {
        colNames[NOMBRE] = "NOMBRE";
        colNames[IMPORTADO] = "IMPORTADO";
        colNames[PRECIO] = "PRECIO";
        colNames[TIPO] = "TIPO";
        colNames[PORCENTAJE] = "PORCENTAJE";
        colNames[IMPUESTO] = "IMPUESTO";
        colNames[PRECIOFINAL] = "PRECIOFINAL";
        
    }
   
}

