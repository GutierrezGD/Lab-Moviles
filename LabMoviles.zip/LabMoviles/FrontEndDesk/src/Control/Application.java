/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import LogicaNegocio.FlujoPrincipal;
import Control.ControlProducto;
import Model.Model;
import Interfaz.Vista;
import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.border.Border;

/**
 *
 * @author Alvaro Viquez
 */
public class Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Control domainModel = new Control();
        Model model = new Model();
        Vista vista= new Vista();
        PRODUCTO_VISTA=vista;
        PRODUCTO_VISTA.setVisible(true);
        ControlProducto controlProducto = new ControlProducto(vista,model,domainModel);   
     
    }
 
    public static Vista PRODUCTO_VISTA;
    
    public static Border BORDER_ERROR = BorderFactory.createLineBorder(Color.red);
    public static Border BORDER_NOBORDER = BorderFactory.createLineBorder(Color.red);
}
